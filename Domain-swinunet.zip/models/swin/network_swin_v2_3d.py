# -----------------------------------------------------------------------------------
# SwinIRx modified: Based on Swinv2 and SwinIR
# -----------------------------------------------------------------------------------
import torch
import torch.nn as nn
from .swinv2_utils_3d import RSTB3D, Upsample3D
from .utils_3d import PatchEmbed3D, PatchUnEmbed3D
import numpy as np
from timm.models.layers import trunc_normal_
import torch.nn.functional as F


class Swin_v2_3D(nn.Module):
    r""" SwinIRx 3D
        A 3D version of SwinIRx.

    Args:
        img_size (int | tuple(int)): Input image size. Default 64
        patch_size (int | tuple(int)): Patch size. Default: 1
        in_chans (int): Number of input image channels. Default: 3
        embed_dim (int): Patch embedding dimension. Default: 96
        depths (tuple(int)): Depth of each Swin Transformer layer.
        num_heads (tuple(int)): Number of attention heads in different layers.
        window_size (int): Window size. Default: 7
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim. Default: 4
        qkv_bias (bool): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float): Override default qk scale of head_dim ** -0.5 if set. Default: None
        drop_rate (float): Dropout rate. Default: 0
        attn_drop_rate (float): Attention dropout rate. Default: 0
        drop_path_rate (float): Stochastic depth rate. Default: 0.1
        norm_layer (nn.Module): Normalization layer. Default: nn.LayerNorm.
        ape (bool): If True, add absolute position embedding to the patch embedding. Default: False
        patch_norm (bool): If True, add normalization after patch embedding. Default: True
        use_checkpoint (bool): Whether to use checkpointing to save memory. Default: False
        upscale: Upscale factor. 2/3/4/8 for image SR, 1 for denoising and compress artifact reduction
        img_range: Image range. 1. or 255.
        upsampler: The reconstruction reconstruction module. 'pixelshuffle'/'pixelshuffledirect'/'nearest+conv'/None
        resi_connection: The convolutional block before residual connection. '1conv'/'3conv'
    """

    def __init__(self, img_size=64, patch_size=1, in_chans=3, nclass=4,
                 embed_dim=96, depths=[6, 6, 6, 6], num_heads=[6, 6, 6, 6],
                 window_size=7, mlp_ratio=4., qkv_bias=True, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0.1,
                 norm_layer=nn.LayerNorm, ape=False, patch_norm=True,
                 use_checkpoint=False, upscale=2, img_range=1., upsampler='', resi_connection='1conv',
                 residual=False, decoder_only=False,
                 **kwargs):

        super(Swin_v2_3D, self).__init__()
        num_in_ch = in_chans
        num_out_ch = nclass  # FIX: Output channels should be number of classes for segmentation
        num_feat = 64

        self.residual = residual
        self.img_range = img_range
        if in_chans == 3:
            # This is for RGB images, might need adjustment for medical images
            rgb_mean = (0.4488, 0.4371, 0.4040)
            self.mean = torch.Tensor(rgb_mean).view(1, 3, 1, 1, 1)
        else:
            self.mean = torch.zeros(1, 1, 1, 1, 1)

        self.upscale = upscale if upscale else 1
        self.upsampler = upsampler
        self.window_size = window_size

        #####################################################################################################
        ################################### 1, shallow feature extraction ###################################
        self.conv_first = nn.Conv3d(num_in_ch, embed_dim, 3, 1, 1)
        self.conv_sec = nn.Conv3d(embed_dim, embed_dim, 3, 1, 1)

        #####################################################################################################
        ################################### 2, deep feature extraction ######################################
        self.num_layers = len(depths)
        self.embed_dim = embed_dim
        self.ape = ape
        self.patch_norm = patch_norm
        self.num_features = embed_dim
        self.mlp_ratio = mlp_ratio

        # split image into non-overlapping patches
        self.patch_embed = PatchEmbed3D(
            img_size=img_size, patch_size=patch_size, in_chans=embed_dim, embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)
        num_patches = self.patch_embed.num_patches
        patches_resolution = self.patch_embed.patches_resolution
        self.patches_resolution = patches_resolution

        # merge non-overlapping patches into image
        self.patch_unembed = PatchUnEmbed3D(
            img_size=img_size, patch_size=patch_size, in_chans=embed_dim, embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)

        # absolute position embedding
        if self.ape:
            self.absolute_pos_embed = nn.Parameter(torch.zeros(1, num_patches, embed_dim))
            trunc_normal_(self.absolute_pos_embed, std=.02)

        self.pos_drop = nn.Dropout(p=drop_rate)

        # stochastic depth
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule

        # build Residual Swin Transformer blocks (RSTB)
        self.layers = nn.ModuleList()
        self.feature_layer = int(np.round(self.num_layers/2))

        for i_layer in range(self.num_layers):
            layer = RSTB3D(dim=embed_dim,
                         input_resolution=(patches_resolution[0],
                                           patches_resolution[1],
                                           patches_resolution[2]),
                         depth=depths[i_layer],
                         num_heads=num_heads[i_layer],
                         window_size=window_size,
                         mlp_ratio=self.mlp_ratio,
                         qkv_bias=qkv_bias, qk_scale=qk_scale,
                         drop=drop_rate, attn_drop=attn_drop_rate,
                         drop_path=dpr[sum(depths[:i_layer]):sum(depths[:i_layer + 1])],  # no impact on SR results
                         norm_layer=norm_layer,
                         downsample=None,
                         use_checkpoint=use_checkpoint,
                         img_size=img_size,
                         patch_size=patch_size,
                         resi_connection=resi_connection

                         )
            self.layers.append(layer)
        self.norm = norm_layer(self.num_features)

        # build the last conv layer in deep feature extraction
        if resi_connection == '1conv':
            self.conv_after_body = nn.Conv3d(embed_dim, embed_dim, 3, 1, 1)
        elif resi_connection == '3conv':
            # to save parameters and memory
            self.conv_after_body = nn.Sequential(nn.Conv3d(embed_dim, embed_dim // 4, 3, 1, 1),
                                                 nn.LeakyReLU(negative_slope=0.2, inplace=True),
                                                 nn.Conv3d(embed_dim // 4, embed_dim // 4, 1, 1, 0),
                                                 nn.LeakyReLU(negative_slope=0.2, inplace=True),
                                                 nn.Conv3d(embed_dim // 4, embed_dim, 3, 1, 1),
                                                #  nn.LeakyReLU(negative_slope=0.2, inplace=True),  # TODO
                                                 )

        #####################################################################################################
        ################################ 3, high quality image reconstruction ################################
        if self.upsampler == 'pixelshuffle':
            # for classical SR
            self.conv_before_upsample = nn.Sequential(nn.Conv3d(embed_dim, num_feat, 3, 1, 1),
                                                      nn.LeakyReLU(inplace=True))
            self.upsample = Upsample3D(self.upscale, num_feat)
            self.conv_last = nn.Conv3d(num_feat, num_out_ch, 3, 1, 1)

        elif self.upsampler == 'pixelshuffledirect':
            # This option is not directly convertible to 3D in a straightforward way
            # and is not used by the default brain tumor segmentation task.
            # Falling back to a standard upsampling method.
            self.conv_last = nn.Sequential(
                nn.Conv3d(embed_dim, num_out_ch * (self.upscale ** 3), 3, 1, 1),
                nn.LeakyReLU(inplace=True)
            )

        elif self.upsampler == 'nearest+conv':
            self.conv_before_upsample = nn.Sequential(nn.Conv3d(embed_dim, num_feat, 3, 1, 1),
                                                      nn.LeakyReLU(inplace=True))
            self.conv_up1 = nn.Conv3d(num_feat, num_feat, 3, 1, 1)
            self.conv_up2 = nn.Conv3d(num_feat, num_feat, 3, 1, 1)
            self.conv_hr = nn.Conv3d(num_feat, num_feat, 3, 1, 1)
            self.conv_last = nn.Conv3d(num_feat, num_out_ch, 3, 1, 1)
            self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        else:
            # for image denoising and JPEG compression artifact reduction
            self.conv_last = nn.Conv3d(embed_dim, num_out_ch, 3, 1, 1)

        # New reconstruction head
        self.reconstruction_head = nn.Conv3d(embed_dim, in_chans, 3, 1, 1)

        self.apply(self._init_weights)


    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'absolute_pos_embed'}

    @torch.jit.ignore
    def no_weight_decay_keywords(self):
        return {'relative_position_bias_table'}

    def check_image_size(self, x):
        _, _, d, h, w = x.size()
        mod_pad_d = (self.window_size - d % self.window_size) % self.window_size
        mod_pad_h = (self.window_size - h % self.window_size) % self.window_size
        mod_pad_w = (self.window_size - w % self.window_size) % self.window_size
        x = F.pad(x, (0, mod_pad_w, 0, mod_pad_h, 0, mod_pad_d), 'reflect')
        return x

    def encoder(self, x, return_all_features=False):
        self.x_size = (x.shape[2], x.shape[3], x.shape[4])
        x = self.patch_embed(x)
        x_embed = x

        if self.ape:
            x = x + self.absolute_pos_embed

        x = self.pos_drop(x)

        if return_all_features:
            all_features = []
            for i in range(self.num_layers):
                x = self.layers[i](x, self.x_size)
                all_features.append(x)
            return all_features
        else:
            for i in range(self.feature_layer):
                x = self.layers[i](x, self.x_size)
            return x + x_embed

    def decoder(self, x):
        x_embed = x

        for i in range(self.num_layers - self.feature_layer):
            x = self.layers[self.feature_layer + i](x, self.x_size)

        x = self.norm(x + x_embed)   # B L C
        x = self.patch_unembed(x, self.x_size)

        return x

    def forward(self, x, downsample=False, dual=False, D=False, visualization=False, partial=None):
        # Shallow feature extraction
        x_first = self.conv_first(x)
        
        if dual:
            nb = x.shape[0] // 4
            
            # Deep feature extraction for all inputs in the dual path
            all_enc_features = self.encoder(x_first[:3*nb], return_all_features=True)

            # Split features into anatomical and domain representations
            anatomical_features = [f for f in all_enc_features[:self.feature_layer]]
            domain_features = [f for f in all_enc_features[self.feature_layer:]]
            
            outputs = {}
            
            # --- Recombination and Reconstruction Logic ---
            # Get sigmoid score from the bridge of the U-Net structure
            decoded_anatomical_bridge = self.decoder(anatomical_features[-1])
            s_score_feat = self.conv_sec(decoded_anatomical_bridge)
            s_score = torch.sigmoid(s_score_feat)

            # Reconstruct 'a' using its own domain features
            domain_a_features = self.encoder(x_first[:nb], return_all_features=False)
            decoded_a = self.decoder(domain_a_features)
            outputs['a'] = self.reconstruction_head(decoded_a)
            outputs['domain_a'] = domain_a_features
            
            if D:
                # Reconstruct 'a_prime_mix' by mixing domain features
                at_domain_features = self.encoder(x_first[2*nb:3*nb], return_all_features=False)
                aprime_domain_features = self.encoder(x_first[nb:2*nb], return_all_features=False)
                outputs['domain_at'] = at_domain_features
                outputs['domain_aprime'] = aprime_domain_features

                # Mix features based on the score from anatomical part
                # Downsample s_score to latent space resolution and reshape for broadcasting
                s_score_latent = F.interpolate(s_score, size=self.patches_resolution, mode='trilinear', align_corners=False)
                B, C, D_p, H_p, W_p = s_score_latent.shape
                s_score_latent = s_score_latent.view(B, C, -1).transpose(1, 2)
                
                mixed_domain = s_score_latent[nb:2*nb] * at_domain_features + (1 - s_score_latent[nb:2*nb]) * aprime_domain_features
                decoded_aprime_mix = self.decoder(mixed_domain)
                outputs['a_prime_mix'] = self.reconstruction_head(decoded_aprime_mix)

            # --- Segmentation Logic ---
            # Use anatomical features for segmentation
            decoded_seg = self.decoder(anatomical_features[-1])
            
            res_seg = self.conv_after_body(decoded_seg)
            if self.upsampler in ['pixelshuffle', 'nearest+conv']:
                x_seg = self.conv_before_upsample(res_seg)
                if self.upsampler == 'nearest+conv':
                    x_seg = self.lrelu(self.conv_hr(x_seg))
                outputs['masks'] = self.conv_last(x_seg)
            else:
                outputs['masks'] = self.conv_last(res_seg)

            return outputs

        elif visualization:
            # Visualization logic can be implemented here similarly if needed
            rep = self.encoder(x_first)
            out = self.forward_feature(rep, x_first, downsample=downsample)
            return {'masks': out, 'full': out, 'anatomical': out, 'domain': out} # Placeholder implementation
        else:
            # Standard segmentation forward pass
            rep = self.encoder(x_first)
            out = self.forward_feature(rep, x_first, downsample=downsample)
            return {'masks': out}

    def get_feature(self, x, return_mean=False):
        self.D, self.H, self.W = x.shape[2:]
        x = self.check_image_size(x)
        self.mean = self.mean.type_as(x)
        x = (x - self.mean) * self.img_range

        if self.residual:
            self.x_res = x.clone()

        self.x_first = self.conv_first(x)
        self.rep = self.encoder(self.x_first)

        if return_mean:
            return self.rep, self.mean, self.x_size, self.D, self.H, self.W
        return self.rep

    def forward_feature(self, x, x_first, require_grad=True, input_mean=None, input_x_size=None, D=None, H=None, W=None, downsample=False):
        if input_mean is not None:
            self.mean = input_mean

        if input_x_size is not None:
            self.x_size = input_x_size
            self.D=D
            self.H=H
            self.W=W

        res = self.conv_after_body(self.decoder(x))

        if self.residual:
            res = res + x_first

        # if require_grad:
        if self.upsampler == 'pixelshuffle' and downsample:
            x = self.conv_before_upsample(res)
            x = self.conv_last(self.upsample(x))
            # x = self.conv_last_sr(self.upsample(x))

        elif self.upsampler == 'pixelshuffledirect':
             x = self.conv_last(res) # Simplified due to lack of direct 3D equivalent
             # Proper 3D pixel shuffle logic would be needed here if used.

        elif self.upsampler == 'nearest+conv' and downsample:
            x = self.conv_before_upsample(res)
            x = self.lrelu(self.conv_up1(torch.nn.functional.interpolate(x, scale_factor=2, mode='trilinear', align_corners=False)))
            x = self.lrelu(self.conv_up2(torch.nn.functional.interpolate(x, scale_factor=2, mode='trilinear', align_corners=False)))
            x = self.conv_last(self.lrelu(self.conv_hr(x)))
        else:
            # When not upsampling, ensure channel dimensions are correct before the final convolution
            if self.upsampler in ['pixelshuffle', 'nearest+conv']:
                x = self.conv_before_upsample(res)
                if self.upsampler == 'nearest+conv':
                     x = self.lrelu(self.conv_hr(x))
                x = self.conv_last(x)
            else:
                x = self.conv_last(res)


        x = x / self.img_range + self.mean

        return x[:, :, :self.D*self.upscale, :self.H*self.upscale, :self.W*self.upscale]



    def flops(self):
        flops = 0
        H, W = self.patches_resolution
        flops += H * W * 3 * self.embed_dim * 9
        flops += self.patch_embed.flops()
        for i, layer in enumerate(self.layers):
            flops += layer.flops()
        flops += H * W * 3 * self.embed_dim * self.embed_dim
        flops += self.upsample.flops()
        return flops


if __name__ == '__main__':
    upscale = 4
    window_size = 8
    height = (1024 // upscale // window_size + 1) * window_size
    width = (720 // upscale // window_size + 1) * window_size
    model = Swin_v2_3D(upscale=2, img_size=(height, width),
                   window_size=window_size, img_range=1., depths=[6, 6, 6, 6],
                   embed_dim=60, num_heads=[6, 6, 6, 6], mlp_ratio=2, upsampler='pixelshuffledirect')
    print(model)
    print(height, width, model.flops() / 1e9)

    x = torch.randn((1, 3, height, width))
    x = model(x)
    print(x.shape)

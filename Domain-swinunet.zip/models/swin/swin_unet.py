import torch
import torch.nn as nn
import torch.nn.functional as F
from .swin_transformer_unet_skip_expand_decoder_sys import SwinTransformerSys

class SwinUnet(nn.Module):
    def __init__(self, config, img_size=224, num_classes=4):
        super(SwinUnet, self).__init__()
        self.num_classes = num_classes
        self.config = config

        # Swin-U-Net configuration
        self.swin_unet = SwinTransformerSys(
            img_size=img_size,
            patch_size=4,
            in_chans=3,
            num_classes=self.num_classes,
            embed_dim=96,
            depths=[2, 2, 6, 2],
            depths_decoder=[2, 2, 6, 2],
            num_heads=[3, 6, 12, 24],
            window_size=7,
            mlp_ratio=4.,
            qkv_bias=True,
            qk_scale=None,
            drop_rate=0.0,
            attn_drop_rate=0.0,
            drop_path_rate=0.1,
            norm_layer=nn.LayerNorm,
            patch_norm=True,
            use_checkpoint=False,
            final_upsample="expand_first"
        )

    def forward(self, x, dual=False, D=False, partial=None, visualization=False):
        if x.size()[1] == 1:
            x = x.repeat(1,3,1,1)
        
        # Get segmentation output
        logits = self.swin_unet(x)
        
        # Always resize output to match input size
        if logits.shape[-2:] != x.shape[-2:]:
            target_size = x.shape[-2:]
            logits = F.interpolate(logits, size=target_size, mode='bilinear', align_corners=True)
        
        if dual:
            batch_size = x.size(0)
            if partial is not None:
                batch_size = partial
            
            # For Domain Game compatibility
            output = {
                'masks': logits,
                'a': x[:batch_size],  # Original image
                'a_prime_mix': x[3*batch_size:],  # Mixed image
                'domain_a': [x[:batch_size]],  # Domain features
                'domain_at': [x[2*batch_size:3*batch_size]]  # Target domain features
            }
            
            if visualization:
                # Create tensors for visualization
                output.update({
                    'full': logits.clone(),  # Use segmentation output
                    'anatomical': logits.clone(),  # Use segmentation output
                    'domain': logits.clone(),  # Use segmentation output
                    'full_comp': logits.clone(),  # Use segmentation output
                    'anatomical_comp': logits.clone(),  # Use segmentation output
                    'domain_comp': logits.clone()  # Use segmentation output
                })
            return output
        
        return logits

    def load_from(self, pretrained_path):
        if pretrained_path is not None:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            pretrained_dict = torch.load(pretrained_path, map_location=device)
            if "model" not in pretrained_dict:
                print("---start load pretrained model by splitting---")
                pretrained_dict = {k[17:]:v for k,v in pretrained_dict.items()}
                for k in list(pretrained_dict.keys()):
                    if "output" in k:
                        print("delete key:{}".format(k))
                        del pretrained_dict[k]
                msg = self.swin_unet.load_state_dict(pretrained_dict, strict=False)
                return
            pretrained_dict = pretrained_dict['model']
            print("---start load pretrained model of swin encoder---")

            model_dict = self.swin_unet.state_dict()
            full_dict = copy.deepcopy(pretrained_dict)
            for k, v in pretrained_dict.items():
                if "layers." in k:
                    current_layer_num = 3-int(k[7:8])
                    current_k = "layers_up." + str(current_layer_num) + k[8:]
                    full_dict.update({current_k:v})
            for k in list(full_dict.keys()):
                if k in model_dict:
                    if full_dict[k].shape != model_dict[k].shape:
                        print("delete:{};shape pretrain:{};shape model:{}".format(k,v.shape,model_dict[k].shape))
                        del full_dict[k]

            msg = self.swin_unet.load_state_dict(full_dict, strict=False)
        else:
            print("no pretrained weights")

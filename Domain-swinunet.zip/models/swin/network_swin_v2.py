# -----------------------------------------------------------------------------------
# SwinIRx modified: Based on Swinv2 and SwinIR
# -----------------------------------------------------------------------------------
import torch
import torch.nn as nn
from .swin.swinv2_utils import Upsample, RSTB, UpsampleOneStep
from .swin.utils import  PatchUnEmbed, PatchEmbed
import numpy as np
from timm.models.layers import trunc_normal_
import torch.nn.functional as F


class Swin_v2(nn.Module):
    r""" SwinIRx
        Based on PyTorch impl of : `SwinIR: Image Restoration Using Swin Transformer`, based on Swin Transformer.

    Args:
        img_size (int | tuple(int)): Input image size. Default 64
        patch_size (int | tuple(int)): Patch size. Default: 1
        in_chans (int): Number of input image channels. Default: 3
        embed_dim (int): Patch embedding dimension. Default: 96
        depths (tuple(int)): Depth of each Swin Transformer layer.
        num_heads (tuple(int)): Number of attention heads in different layers.
        window_size (int): Window size. Default: 7
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim. Default: 4
        qkv_bias (bool): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float): Override default qk scale of head_dim ** -0.5 if set. Default: None
        drop_rate (float): Dropout rate. Default: 0
        attn_drop_rate (float): Attention dropout rate. Default: 0
        drop_path_rate (float): Stochastic depth rate. Default: 0.1
        norm_layer (nn.Module): Normalization layer. Default: nn.LayerNorm.
        ape (bool): If True, add absolute position embedding to the patch embedding. Default: False
        patch_norm (bool): If True, add normalization after patch embedding. Default: True
        use_checkpoint (bool): Whether to use checkpointing to save memory. Default: False
        upscale: Upscale factor. 2/3/4/8 for image SR, 1 for denoising and compress artifact reduction
        img_range: Image range. 1. or 255.
        upsampler: The reconstruction reconstruction module. 'pixelshuffle'/'pixelshuffledirect'/'nearest+conv'/None
        resi_connection: The convolutional block before residual connection. '1conv'/'3conv'
    """

    def __init__(self, img_size=64, patch_size=1, in_chans=3,
                 embed_dim=96, depths=[6, 6, 6, 6], num_heads=[6, 6, 6, 6],
                 window_size=7, mlp_ratio=4., qkv_bias=True, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0.1,
                 norm_layer=nn.LayerNorm, ape=False, patch_norm=True,
                 use_checkpoint=False, upscale=2, img_range=1., upsampler='', resi_connection='1conv', 
                 residual=False, decoder_only=False, nclass=None,
                 **kwargs):

        super(Swin_v2, self).__init__()
        num_in_ch = in_chans
        # Use nclass for segmentation output, fallback to in_chans for other tasks
        num_out_ch = nclass if nclass is not None else in_chans
        num_feat = 64

        self.residual = residual
        self.img_range = img_range
        # Use nclass for output channels, fallback to in_chans for other tasks
        num_out_ch = nclass if nclass is not None else in_chans
        if in_chans == 3:
            rgb_mean = (0.4488, 0.4371, 0.4040)
            self.mean = torch.Tensor(rgb_mean).view(1, 3, 1, 1)
        else:
            # For other input channels, use zeros with correct input channels
            self.mean = torch.zeros(1, in_chans, 1, 1)
            
        self.upscale = upscale if upscale else 1
        self.upsampler = upsampler
        self.window_size = window_size

        #####################################################################################################
        ################################### 1, shallow feature extraction ###################################
        self.conv_first = nn.Conv2d(num_in_ch, embed_dim, 3, 1, 1)
        self.conv_sec = nn.Conv2d(embed_dim, embed_dim, 3, 1, 1)
        
        
        #####################################################################################################
        ################################### 2, deep feature extraction ######################################
        self.num_layers = len(depths)
        self.embed_dim = embed_dim
        self.ape = ape
        self.patch_norm = patch_norm
        self.num_features = embed_dim
        self.mlp_ratio = mlp_ratio

        # split image into non-overlapping patches
        self.patch_embed = PatchEmbed(
            img_size=img_size, patch_size=patch_size, in_chans=embed_dim, embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)
        num_patches = self.patch_embed.num_patches
        patches_resolution = self.patch_embed.patches_resolution
        self.patches_resolution = patches_resolution

        # merge non-overlapping patches into image
        self.patch_unembed = PatchUnEmbed(
            img_size=img_size, patch_size=patch_size, in_chans=embed_dim, embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)

        # absolute position embedding
        if self.ape:
            self.absolute_pos_embed = nn.Parameter(torch.zeros(1, num_patches, embed_dim))
            trunc_normal_(self.absolute_pos_embed, std=.02)

        self.pos_drop = nn.Dropout(p=drop_rate)

        # stochastic depth
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule

        # build Residual Swin Transformer blocks (RSTB)
        self.layers = nn.ModuleList()
        self.feature_layer = int(np.round(self.num_layers/2))
        
        for i_layer in range(self.num_layers):
            layer = RSTB(dim=embed_dim,
                         input_resolution=(patches_resolution[0],
                                           patches_resolution[1]),
                         depth=depths[i_layer],
                         num_heads=num_heads[i_layer],
                         window_size=window_size,
                         mlp_ratio=self.mlp_ratio,
                         qkv_bias=qkv_bias, qk_scale=qk_scale,
                         drop=drop_rate, attn_drop=attn_drop_rate,
                         drop_path=dpr[sum(depths[:i_layer]):sum(depths[:i_layer + 1])],  # no impact on SR results
                         norm_layer=norm_layer,
                         downsample=None,
                         use_checkpoint=use_checkpoint,
                         img_size=img_size,
                         patch_size=patch_size,
                         resi_connection=resi_connection

                         )
            self.layers.append(layer)
        self.norm = norm_layer(self.num_features)

        # build the last conv layer in deep feature extraction
        if resi_connection == '1conv':
            self.conv_after_body = nn.Conv2d(embed_dim, embed_dim, 3, 1, 1)
        elif resi_connection == '3conv':
            # to save parameters and memory
            self.conv_after_body = nn.Sequential(nn.Conv2d(embed_dim, embed_dim // 4, 3, 1, 1),
                                                 nn.LeakyReLU(negative_slope=0.2, inplace=True),
                                                 nn.Conv2d(embed_dim // 4, embed_dim // 4, 1, 1, 0),
                                                 nn.LeakyReLU(negative_slope=0.2, inplace=True),
                                                 nn.Conv2d(embed_dim // 4, embed_dim, 3, 1, 1),
                                                #  nn.LeakyReLU(negative_slope=0.2, inplace=True),  # TODO
                                                 )
        
        
        #####################################################################################################
        ################################ 3, high quality image reconstruction ################################
        if self.upsampler == 'pixelshuffle':
            # for classical SR
            self.conv_before_upsample = nn.Sequential(nn.Conv2d(embed_dim, num_feat, 3, 1, 1),
                                                      nn.LeakyReLU(inplace=True))

            self.upsample = Upsample(upscale, num_feat)
            self.conv_last = nn.Conv2d(num_feat, num_out_ch, 3, 1, 1)


        elif self.upsampler == 'pixelshuffledirect':
            # for lightweight SR (to save parameters)
            self.upsample = UpsampleOneStep(upscale, embed_dim, num_out_ch,
                                            (patches_resolution[0], patches_resolution[1]))
            
        elif self.upsampler == 'nearest+conv':
            # for real-world SR (less artifacts)
            # assert self.upscale == 4, 'only support x4 now.'
            self.conv_before_upsample = nn.Sequential(nn.Conv2d(embed_dim, num_feat, 3, 1, 1),
                                                      nn.LeakyReLU(inplace=True))
            self.conv_up1 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
            self.conv_up2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
            self.conv_hr = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
            self.conv_last = nn.Conv2d(num_feat, num_out_ch, 3, 1, 1)
            self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        else:
            # for image denoising and JPEG compression artifact reduction
            self.conv_last = nn.Conv2d(embed_dim, num_out_ch, 3, 1, 1)

        self.apply(self._init_weights)


    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'absolute_pos_embed'}

    @torch.jit.ignore
    def no_weight_decay_keywords(self):
        return {'relative_position_bias_table'}

    def check_image_size(self, x):
        _, _, h, w = x.size()
        mod_pad_h = (self.window_size - h % self.window_size) % self.window_size
        mod_pad_w = (self.window_size - w % self.window_size) % self.window_size
        x = F.pad(x, (0, mod_pad_w, 0, mod_pad_h), 'reflect')
        return x
    
    def encoder(self, x):
        self.x_size = (x.shape[2], x.shape[3])
        x = self.patch_embed(x)
        x_embed = x

        if self.ape:
            x = x + self.absolute_pos_embed

        x = self.pos_drop(x)

        for i in range(self.feature_layer): 
            x = self.layers[i](x, self.x_size)  # + x?

        return x + x_embed
    
    def decoder(self, x):
        x_embed = x

        for i in range(self.num_layers - self.feature_layer):
            x = self.layers[self.feature_layer + i](x, self.x_size)

        x = self.norm(x + x_embed)   # B L C
        x = self.patch_unembed(x, self.x_size)

        return x

    def forward(self, x, downsample=False, dual=False, D=False, visualization=False, partial=None):
        
        if dual:
            # For dual path processing (Domain Game method)
            nb = partial if partial is not None else x.shape[0] // 4
            
            # Get shallow features for all inputs
            x_first = x  # In 2D, we don't need conv_first layer like 3D version
            
            outputs = {}
            
            # --- Domain Game Logic Implementation ---
            # Process anatomical features (first 3*nb samples)
            anatomical_rep = self.get_feature(x_first[:3*nb])
            anatomical_out = self.forward_feature(anatomical_rep, downsample=downsample)
            
            # Generate segmentation masks from anatomical features
            outputs['masks'] = anatomical_out
            
            # Reconstruct 'a' using its own domain features (first nb samples)
            domain_a_rep = self.get_feature(x_first[:nb])
            domain_a_out = self.forward_feature(domain_a_rep, downsample=downsample)
            outputs['a'] = domain_a_out
            outputs['domain_a'] = domain_a_rep
            
            if D:
                # Process additional domain features for mixing
                at_domain_rep = self.get_feature(x_first[2*nb:3*nb])
                aprime_domain_rep = self.get_feature(x_first[nb:2*nb])
                
                outputs['domain_at'] = at_domain_rep
                outputs['domain_aprime'] = aprime_domain_rep
                
                # Simple mixing for 2D (can be enhanced later)
                # For now, use a simple average mixing
                mixed_rep = 0.5 * at_domain_rep + 0.5 * aprime_domain_rep
                mixed_out = self.forward_feature(mixed_rep, downsample=downsample)
                outputs['a_prime_mix'] = mixed_out
            
            return outputs
            
        elif visualization:
            # Visualization mode
            self.rep = self.get_feature(x)
            out = self.forward_feature(self.rep, downsample=downsample)
            
            # Create comparison views for visualization
            # For 2D data, we'll create simple comparison views
            b, c, h, w = out.shape
            full_comp = out.clone()  # Use the same output for comparison
            anatomical_comp = out.clone()
            domain_comp = out.clone()
            
            return {
                'masks': out, 
                'full': out, 
                'anatomical': out, 
                'domain': out,
                'full_comp': full_comp,
                'anatomical_comp': anatomical_comp,
                'domain_comp': domain_comp
            }
        else:
            # Standard forward pass
            self.rep = self.get_feature(x)
            out = self.forward_feature(self.rep, downsample=downsample)
            return out
    
    def get_feature(self, x, return_mean=False):
        self.H, self.W = x.shape[2:]
        x = self.check_image_size(x)

        self.mean = self.mean.type_as(x)
        x = (x - self.mean) * self.img_range
        
        if self.residual:
            self.x_res = x.clone()
            
        # for image denoising and JPEG compression artifact reduction
        self.x_first = self.conv_first(x)  # self.conv_sec(  )
        self.rep = self.encoder(self.x_first)
          
        if return_mean:
            return self.rep, self.mean, self.x_size, self.H, self.W

        return self.rep
            
    def forward_feature(self, x, require_grad=True, input_mean=None, input_x_size=None, H=None, W=None, downsample=False):
        if input_mean != None:
            self.mean = input_mean

        if input_x_size != None:
            self.x_size = input_x_size
            self.H=H
            self.W=W

        res = self.conv_after_body(self.decoder(x))

        if self.residual:
            res = res + self.x_first

        # if require_grad:
        if self.upsampler == 'pixelshuffle' and downsample:
            x = self.conv_before_upsample(res)
            x = self.conv_last(self.upsample(x))
            # x = self.conv_last_sr(self.upsample(x))

        elif self.upsampler == 'nearest+conv' and downsample:
            # for real-world SR

            x = self.conv_before_upsample(x)
            x = self.lrelu(self.conv_up1(torch.nn.functional.interpolate(x, scale_factor=2, mode='nearest')))
            x = self.lrelu(self.conv_up2(torch.nn.functional.interpolate(x, scale_factor=2, mode='nearest')))
            x = self.conv_last(self.lrelu(self.conv_hr(x)))
        else:
            x = self.conv_last(res)


        # Adjust mean to match output channels for segmentation tasks
        if x.shape[1] != self.mean.shape[1]:
            # For segmentation output, use zeros for additional channels
            if x.shape[1] > self.mean.shape[1]:
                # Extend mean with zeros for additional channels
                extended_mean = torch.zeros_like(x)
                extended_mean[:, :self.mean.shape[1]] = self.mean
                x = x / self.img_range + extended_mean
            else:
                # Truncate mean if needed
                x = x / self.img_range + self.mean[:, :x.shape[1]]
        else:
            x = x / self.img_range + self.mean
        
        # Crop to original input size to handle padding from check_image_size
        return x[:, :, :self.H, :self.W]
    
    
    
    def flops(self):
        flops = 0
        H, W = self.patches_resolution
        flops += H * W * 3 * self.embed_dim * 9
        flops += self.patch_embed.flops()
        for i, layer in enumerate(self.layers):
            flops += layer.flops()
        flops += H * W * 3 * self.embed_dim * self.embed_dim
        flops += self.upsample.flops()
        return flops


if __name__ == '__main__':
    upscale = 4
    window_size = 8
    height = (1024 // upscale // window_size + 1) * window_size
    width = (720 // upscale // window_size + 1) * window_size
    model = Swin_v2(upscale=2, img_size=(height, width),
                   window_size=window_size, img_range=1., depths=[6, 6, 6, 6],
                   embed_dim=60, num_heads=[6, 6, 6, 6], mlp_ratio=2, upsampler='pixelshuffledirect')
    print(model)
    print(height, width, model.flops() / 1e9)

    x = torch.randn((1, 3, height, width))
    x = model(x)
    print(x.shape)

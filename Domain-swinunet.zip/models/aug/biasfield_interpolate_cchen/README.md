This code base is adapted from an eariler version of [adversarial training pipeline](https://github.com/cherise215/AdvBias) written by Chen Chen. 

You are highly encouraged to check out the original adversarial augmentation and cooperative training projects!

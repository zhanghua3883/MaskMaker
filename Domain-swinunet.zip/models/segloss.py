"""
Extended from implementations by Dr. Jo Schlemper
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function, Variable
import numpy as np
import math


class One_Hot(nn.Module):
    def __init__(self, depth):
        super(One_Hot, self).__init__()
        self.depth = depth
        self.ones = torch.eye(depth).cuda()

    def forward(self, X_in):
        """
        Args:
            added
        """
        n_dim = X_in.dim()
        output_size = X_in.size() + torch.Size([self.depth]) #[nb/nx/nz, ...., nc]
        num_element = X_in.numel()
        X_in = X_in.data.long().view(num_element)
        out = Variable(self.ones.index_select(0, X_in)).view(output_size)
        if n_dim > 1:
            return out.permute(0, -1, *range(1, n_dim)).squeeze(dim=2).float() # [nb/nx/n\, nc, ny]
        else:
            return out.float()

    def __repr__(self):
        return self.__class__.__name__ + "({})".format(self.depth)


class SoftDiceLoss(nn.Module):
    def __init__(self, n_classes):
        super(SoftDiceLoss, self).__init__()
        self.one_hot_encoder = One_Hot(n_classes).forward
        self.n_classes = n_classes
        self.weights = None  # Will be set from trainer

    def set_weights(self, weights):
        """Set class weights for weighted Dice loss"""
        self.weights = weights

    def forward(self, input, target):
        """
        input: logits : nb x nc x H x W
        target: dense mask
        """
        smooth = 1  #e-5
        batch_size = input.size(0)

        # Ensure input and target have the same spatial dimensions
        if input.shape[-2:] != target.shape[-2:]:
            input = F.interpolate(input, size=target.shape[-2:], mode='bilinear', align_corners=True)
        
        # Ensure batch sizes match
        if input.size(0) != target.size(0):
            input = input[:target.size(0)]
            batch_size = target.size(0)
        
        # Flatten input and apply softmax
        input = F.softmax(input, dim=1)
        input_flat = input.view(batch_size, self.n_classes, -1)
        
        # Convert target to one-hot and flatten
        target = target.contiguous()  # Make tensor contiguous before reshape
        target_one_hot = self.one_hot_encoder(target)
        target_flat = target_one_hot.reshape(batch_size, self.n_classes, -1)  # Use reshape instead of view

        inter = torch.sum(input_flat * target_flat, 2)  # B x C
        union = torch.sum(input_flat, 2) + torch.sum(target_flat, 2) + smooth  # B x C

        # Calculate Dice score for each class separately
        class_dice = ((2.0 * inter) + smooth) / union  # B x C
        
        # Calculate class-wise loss
        class_loss = 1.0 - class_dice  # B x C
        
        # Apply class weights if available
        if self.weights is not None:
            weights = self.weights.to(class_loss.device)
            class_loss = class_loss * weights.view(1, -1)  # B x C
        
        # Average over classes and batch
        score = torch.mean(class_loss)
        return score

class SoftDiceScore(nn.Module):
    """ This is not a loss function! don't use this. To train a network, use ``SoftDiceLoss'' above.
    """

    def __init__(self, n_classes, ignore_chan0 = True):
        """
        Args:
            ignore_chan0: ignore the channel 0 of the segmentation (usually for the background)
        """
        super(SoftDiceScore, self).__init__()
        self.one_hot_encoder = One_Hot(n_classes).forward
        self.n_classes = n_classes
        self.ignore = ignore_chan0

    def forward(self, input, target):
        """ expects input to already be in one_hot encoded data """
        smooth = 1 #1e-5
        batch_size = input.size(0)

        input = F.softmax(input, dim=1).view(batch_size, self.n_classes, -1)
        input = self.one_hot_encoder(torch.argmax(input, 1))
        target = self.one_hot_encoder(target).contiguous().view(batch_size, self.n_classes, -1)

        if self.ignore == True:
            input = input[:,1:, ...]
            target = target[:,1:, ...]


        inter = torch.sum(input * target, 2)
        union = torch.sum(input, 2) + torch.sum(target, 2) + smooth

        # preserve class axis
        score = torch.sum(((2.0 * inter)+ smooth) / union, 0)
        score = score / (float(batch_size))
        print(score.cpu())

        return score

class Efficient_DiceScore(nn.Module):
    """ WARNING: This is not a loss function! don't use this. To train a network, use ``SoftDiceLoss'' above.
        Improving memory efficiency
    """

    def __init__(self, n_classes, ignore_chan0 = True):
        """
        Args:
            ignore_chan0: ignore the channel 0 of the segmentation (usually for the background)
        """
        super(Efficient_DiceScore, self).__init__()
        self.one_hot_encoder = One_Hot(n_classes).forward
        self.n_classes = n_classes
        self.ignore = ignore_chan0

    def forward(self, global_input, global_target, dense_input = False, cutfold = 5):
        """
        Args:
            input: logits, or dense mask otherwise
                    for logits:  with a shape [nz/nb/1, nc, nx, ny]
                    for dense masks: shape [nz/nb/1, 1, nx, ny]
                    cutfold: split the input volume to <cutfold> folds
            target: dense mask instead, always
        """
        assert global_input.dim() == 4
        smooth = 1  #1e-7
        nz = global_input.size(0)
        foldsize = nz // cutfold + 1 #  actual size

        niter = nz // foldsize

        if nz % foldsize == 0:
            pass
        else:
            niter += 1

        assert niter * foldsize >= nz

        global_inter = 0
        global_nz_pred = 0
        global_nz_gth = 0

        # start the loop
        for ii in range( niter ):
            input = global_input[ii * foldsize : (ii + 1) * foldsize, ...].clone()
            target = global_target[ii * foldsize : (ii + 1) * foldsize, ...].clone()

            if dense_input != True:
                # input is logits
                input = F.softmax(input, dim=1).view(-1, self.n_classes) # nxyz, nc
                input = self.one_hot_encoder(torch.argmax(input, 1)) # nxyz, nc
            else:
                input = self.one_hot_encoder( input.view(-1) )


            target = self.one_hot_encoder( target.view(-1)  ) #nxyz, nc

            if self.ignore == True:
                input = input[:,1:, ...]
                target = target[:,1:, ...]

            try:
                inter = torch.sum(input * target, 0)# + smooth # summing over pixel, keep dimension
                nz_pred = torch.sum(input, 0)
                nz_gth = torch.sum(target, 0)

                flat_inter = [] # place holder
            except:
                # magic numbver, probably due to cuda mememory mechanism
                MAGIC_NUMBER = 14000000
                if input.shape[0] < MAGIC_NUMBER:
                    raise ValueError


                flat_inter = input * target
                total_shape = input.shape[0]
                inter = 0
                nz_pred = 0
                nz_gth = 0

                # iterate through it
                for ii in range(total_shape // MAGIC_NUMBER + 1): # python and pytorch allows going over ...
                    inter += torch.sum(flat_inter[MAGIC_NUMBER * ii: MAGIC_NUMBER * (ii+1) ], 0)
                    nz_pred += torch.sum(input[MAGIC_NUMBER * ii: MAGIC_NUMBER * (ii+1) ], 0)
                    nz_gth += torch.sum(target[MAGIC_NUMBER * ii: MAGIC_NUMBER * (ii+1) ], 0)

            del input
            del target
            del flat_inter

            global_inter += inter
            global_nz_pred += nz_pred
            global_nz_gth  += nz_gth

        global_union = global_nz_pred + global_nz_gth + smooth
        score = ((2.0 * global_inter) + smooth) / global_union

        return score

class My_CE(nn.CrossEntropyLoss):
    def __init__(self, nclass, weight, batch_size):
        super(My_CE, self).__init__(weight = weight)
        self.nclass = nclass
        self.one_hot_encoder = One_Hot(nclass)
        self.batch_size = batch_size

    def forward(self, inputs, targets, eps = 0.01):
        # Handle batch size mismatch
        if inputs.size(0) != targets.size(0):
            inputs = inputs[:targets.size(0)]
        
        if not isinstance(targets, torch.LongTensor):
            targets = torch.squeeze(targets, 1)
            targets = targets.cuda()
        
        out = super(My_CE, self).forward(inputs, targets)
        return out


class FocalTverskyLoss(nn.Module):
    def __init__(self, n_classes, alpha=0.7, gamma=0.75):
        super(FocalTverskyLoss, self).__init__()
        self.one_hot_encoder = One_Hot(n_classes).forward
        self.n_classes = n_classes
        self.alpha = alpha
        self.beta = 1 - alpha
        self.gamma = gamma
        self.weights = None

    def set_weights(self, weights):
        """Set class weights for weighted loss"""
        self.weights = weights

    def forward(self, input, target):
        """
        input: logits : nb x nc x H x W
        target: dense mask
        """
        smooth = 1.
        batch_size = input.size(0)

        # Ensure input and target have the same spatial dimensions
        if input.shape[-2:] != target.shape[-2:]:
            input = F.interpolate(input, size=target.shape[-2:], mode='bilinear', align_corners=True)
        
        # Ensure batch sizes match
        if input.size(0) != target.size(0):
            input = input[:target.size(0)]
            batch_size = target.size(0)
        
        # Flatten input and apply softmax
        input_soft = F.softmax(input, dim=1)
        input_flat = input_soft.view(batch_size, self.n_classes, -1)
        
        # Convert target to one-hot and flatten
        target = target.contiguous()
        target_one_hot = self.one_hot_encoder(target)
        target_flat = target_one_hot.reshape(batch_size, self.n_classes, -1)

        # True Positives, False Positives & False Negatives
        tp = torch.sum(input_flat * target_flat, 2)
        fp = torch.sum(input_flat * (1 - target_flat), 2)
        fn = torch.sum((1 - input_flat) * target_flat, 2)

        tversky_index = (tp + smooth) / (tp + self.alpha * fn + self.beta * fp + smooth)
        
        focal_tversky_loss = torch.pow((1 - tversky_index), self.gamma)

        # Apply class weights if available
        if self.weights is not None:
            weights = self.weights.to(focal_tversky_loss.device)
            focal_tversky_loss = focal_tversky_loss * weights.view(1, -1)

        # Average over classes and batch
        loss = torch.mean(focal_tversky_loss)
        return loss


# Dataloader for abdominal images
import glob
import numpy as np
from .utils import niftiio as nio
from .utils import transform_utils as trans
from .utils.abd_dataset_utils import get_normalize_op
from .utils.transform_albu import get_albu_transforms, get_resize_transforms

import torch
import os
from pdb import set_trace
from multiprocessing import Process
from .BasicDataset import BasicDataset
from timm.models.layers import to_3tuple


LABEL_NAME = ["bg", "NCR", "ED", "ET"]

class BrainDataset(BasicDataset):
    def __init__(self, opt, mode, transforms, base_dir, domains: list, **kwargs):
        self.dataset_key = "brain"
        super(BrainDataset, self).__init__(opt, mode, transforms, base_dir, domains, 
                                           LABEL_NAME=LABEL_NAME,
                                           filter_non_labeled=True, **kwargs)
        # For 2D processing, use 2D patch size
        # If using 3D model, patch_depth would be needed, but for 2D swinir we use 2D patches
        if hasattr(opt, 'patch_depth'):
            # 3D mode
            self.patch_size = (opt.patch_depth, opt.fineSize, opt.fineSize)
        else:
            # 2D mode - process slice by slice
            self.patch_size = (opt.fineSize, opt.fineSize)

    def __getitem__(self, index):
        index = index % len(self.actual_dataset)
        curr_dict = self.actual_dataset[index]
        
        img_vol, mask_vol = curr_dict["img"], curr_dict["lb"]
        
        if len(self.patch_size) == 3:
            # 3D mode processing
            pd, ph, pw = self.patch_size
            D, H, W = img_vol.shape
            
            pad_d = max(0, pd - D)
            pad_h = max(0, ph - H)
            pad_w = max(0, pw - W)
            
            if pad_d > 0 or pad_h > 0 or pad_w > 0:
                pad_width = ((pad_d//2, pad_d - pad_d//2), (pad_h//2, pad_h - pad_h//2), (pad_w//2, pad_w - pad_w//2))
                img_vol = np.pad(img_vol, pad_width, mode='constant', constant_values=0)
                mask_vol = np.pad(mask_vol, pad_width, mode='constant', constant_values=0)
                D, H, W = img_vol.shape

            # Randomly crop a 3D patch
            d_start = np.random.randint(0, D - pd) if D > pd else 0
            h_start = np.random.randint(0, H - ph) if H > ph else 0
            w_start = np.random.randint(0, W - pw) if W > pw else 0

            img_patch = img_vol[d_start:d_start+pd, h_start:h_start+ph, w_start:w_start+pw]
            mask_patch = mask_vol[d_start:d_start+pd, h_start:h_start+ph, w_start:w_start+pw]
        else:
            # 2D mode processing - select a random slice
            ph, pw = self.patch_size
            D, H, W = img_vol.shape
            
            # Select a random slice from the volume
            slice_idx = np.random.randint(0, D)
            img_slice = img_vol[slice_idx, :, :]
            mask_slice = mask_vol[slice_idx, :, :]
            
            # Ensure the slice is large enough for the patch, pad if necessary
            pad_h = max(0, ph - H)
            pad_w = max(0, pw - W)
            
            if pad_h > 0 or pad_w > 0:
                pad_width = ((pad_h//2, pad_h - pad_h//2), (pad_w//2, pad_w - pad_w//2))
                img_slice = np.pad(img_slice, pad_width, mode='constant', constant_values=0)
                mask_slice = np.pad(mask_slice, pad_width, mode='constant', constant_values=0)
                H, W = img_slice.shape

            # Randomly crop a 2D patch
            h_start = np.random.randint(0, H - ph) if H > ph else 0
            w_start = np.random.randint(0, W - pw) if W > pw else 0

            img_patch = img_slice[h_start:h_start+ph, w_start:w_start+pw]
            mask_patch = mask_slice[h_start:h_start+ph, w_start:w_start+pw]
        
        # Add channel dimension and convert to tensor
        img_patch = torch.from_numpy(img_patch).float().unsqueeze(0)
        
        if len(self.patch_size) == 3:
            # 3D mode: img_patch shape should be (1, D, H, W), repeat to (3, D, H, W)
            img_patch = img_patch.repeat(3, 1, 1, 1)
        else:
            # 2D mode: img_patch shape should be (1, H, W), repeat to (3, H, W)
            img_patch = img_patch.repeat(3, 1, 1)
            
        mask_patch = torch.from_numpy(mask_patch).long() # No channel dim needed for mask
        
        # Normalization
        mean, std = curr_dict['mean'], curr_dict['std']
        std = 1 if std < 1e-3 else std
        img_patch = (img_patch - mean) / std

        data = {
            "img": img_patch, 
            "lb": mask_patch,
            "scan_id": curr_dict["scan_id"],
            "domain": curr_dict["domain"],  # Add domain information
            # Add other necessary metadata if needed
        }
        return data




from torch.utils.data import DataLoader
import numpy as np
from . import AbdominalDataset as abdominal
from . import BrainDataset as brain
from . import ProstateDataset as prostate
from . import KneeDataset as knee
import os
from .utils import transform_utils as trans

def worker_init_fn(worker_id):
    np.random.seed(np.random.get_state()[1][0] + worker_id)


def get_dataset(opt, idx_pct = [0.7, 0.1, 0.2], chunksize=200):
    print("=== mission:", opt.mission)
    kwargs = dict()
    if not isinstance(opt.tr_domain, list):
        opt.tr_domain = [opt.tr_domain]
    if not isinstance(opt.te_domain, list):
        opt.te_domain = [opt.te_domain]
            
    if opt.mission.lower() == 'abdominal':
        datast_func  = abdominal.AbdominalDataset
        label_name   = abdominal.LABEL_NAME
        basedir      = os.path.join(opt.data_dir, "Abdominal")

    elif opt.mission.lower() == 'knee':
        datast_func  = knee.KneeDataset
        label_name   = knee.LABEL_NAME
        basedir      = os.path.join(opt.data_dir, "Knee")
        kwargs = dict(chunksize = 100 )  # use_diff_axis_view= True,

    elif opt.mission.lower() == 'prostate':
        datast_func  = prostate.ProstateDataset
        label_name   = prostate.LABEL_NAME
        basedir      = os.path.join(opt.data_dir, "Prostate")

    elif opt.mission.lower() == 'brain':
        datast_func  = brain.BrainDataset
        label_name   = brain.LABEL_NAME
        
        # 配置数据集路径，支持多域数据（优先使用处理后的 Brain 目录）
        basedir = opt.data_dir
        brain_basedir = os.path.join(opt.data_dir, "Brain")
        
        # 检查是否需要使用Brain目录（当PED或SSA域存在时）
        use_brain_dir = False
        if os.path.exists(brain_basedir):
            # 检查Brain目录下是否有PED或SSA数据
            for domain in opt.te_domain:
                if "PED" in domain or "SSA" in domain:
                    if os.path.exists(os.path.join(brain_basedir, domain)):
                        use_brain_dir = True
                        break
        
        if use_brain_dir:
            # 使用Brain目录，但GLI数据仍从根目录读取
            print(f"Using Brain directory for PED/SSA data: {brain_basedir}")
            # 不改变basedir，因为GLI数据需要从根目录读取
        else:
            # 回退到原有的多种可能路径
            if not os.path.exists(os.path.join(basedir, "BraTS-GLI-T1C")):
                basedir = os.path.join(opt.data_dir, "brats/Brain")
                if not os.path.exists(basedir):
                    basedir = os.path.join(opt.data_dir, "ASNR-MICCAI-BraTS2023-GLI-Challenge-TrainingData")
                if not os.path.exists(basedir):
                    basedir = "/home/hao/data/medical/Brain"
        
        # 若使用 Brain 目录，规范化域名（将 ASNR 名称映射为 Brain 下的目录名）
        def _normalize_domains(domains):
            mapping = {
                "ASNR-MICCAI-BraTS2023-PED-Challenge-TrainingData": "BraTS-PED-T1C",
                "ASNR-MICCAI-BraTS2023-SSA-Challenge-TrainingData_V2": "BraTS-SSA-T1C",
                # 常见别名兜底
                "PED": "BraTS-PED-T1C",
                "SSA": "BraTS-SSA-T1C",
                "GLI": "BraTS-GLI-T1C",
            }
            out = []
            for d in domains:
                out.append(mapping.get(d, d))
            return out

        if use_brain_dir:
            opt.tr_domain = _normalize_domains(opt.tr_domain)
            opt.te_domain = _normalize_domains(opt.te_domain)
            # 友好提示
            for d in opt.tr_domain + opt.te_domain:
                if "GLI" in d:
                    dp = os.path.join(basedir, d)  # GLI从根目录
                else:
                    dp = os.path.join(brain_basedir, d)  # PED/SSA从Brain目录
                if not os.path.exists(dp):
                    print(f"Warning: Expected domain directory not found: {dp}")
                else:
                    print(f"Found domain directory: {dp}")
            
        idx_pct      = [0.7, 0.15, 0.15]  # train:val:test = 70%:15%:15%
        kwargs = dict( chunksize = opt.chunksize ) 

    else:
        raise NotImplementedError(opt.data_name)

    train_set       = set_dataset(opt, datast_func, "train", basedir, idx_pct = idx_pct,
                                  modality = opt.tr_domain, pseudo = opt.pseudo, **kwargs)
    val_source_set  = set_dataset(opt, datast_func, "val", basedir, idx_pct = idx_pct,
                                  modality = opt.tr_domain, norm_func = train_set.normalize_op)
   
    
    if opt.te_domain[0] == opt.tr_domain[0]:
        # if same domain, then use the normalize op from the source
        test_set        = set_dataset(opt, datast_func, "test", basedir, idx_pct = idx_pct,
                                      modality = opt.te_domain, norm_func = train_set.normalize_op)
        test_source_set = test_set
        
    else:
        test_set        = set_dataset(opt, datast_func, "test_all", basedir, idx_pct = idx_pct,
                                      modality = opt.te_domain, norm_func = None) # train_set.normalize_op) 
        # norm_func used to be None
        
        test_source_set = set_dataset(opt, datast_func, "test", basedir, idx_pct = idx_pct,
                                      modality = opt.tr_domain, norm_func = None) # train_set.normalize_op)


    print(f'Using TR domain {opt.tr_domain}; TE domain {opt.te_domain}')
    train_loader = DataLoader(dataset = train_set, num_workers = opt.nThreads, batch_size = opt.batchSize, 
                              shuffle = True, drop_last = True, worker_init_fn = worker_init_fn,
                              pin_memory = True)

    val_loader = iter(DataLoader(dataset = val_source_set, num_workers = 1, batch_size = 1, 
                                 shuffle = False, pin_memory = True))

    test_tgt_loader = DataLoader(dataset = test_set, num_workers = 1, batch_size = 1, 
                                 shuffle = False, pin_memory = True)

    test_src_loader = DataLoader(dataset = test_source_set, num_workers = 1, batch_size = 1, 
                                 shuffle = False, pin_memory = True)

    loaders = {"train": train_loader, "val": val_loader,
               "test_tgt": test_tgt_loader, "test_src": test_src_loader}

    datasets = {"train": train_set, "val": val_source_set,
                "test_tgt": test_set, "test_src": test_source_set, "label_name": label_name}

    return loaders, datasets


def update_dataset(opt, train_set, train_loader):
    del train_loader
    train_set.update_chunk()
    train_loader = DataLoader(dataset=train_set, num_workers=opt.nThreads,
                              batch_size=opt.batchSize, pin_memory=True,
                              shuffle=True, drop_last=True, worker_init_fn=worker_init_fn)
    return train_loader


def set_dataset(opt, datast_func, mode, basedir, modality, norm_func = None,
                idx_pct = [0.7, 0.1, 0.2], tile_z_dim = 3, pseudo = False, chunksize=200, **kwargs):

    norm_func = None if mode=="train" else norm_func
    tr_func = None if mode == "train" else trans.transform_with_label(trans.tr_aug)

    return datast_func(opt, idx_pct = idx_pct,
                            mode = mode,
                            pseudo = pseudo,
                            domains = modality,
                            transforms = tr_func,
                            base_dir = basedir,
                            extern_norm_fn = norm_func,
                            tile_z_dim = tile_z_dim,
                            chunksize  = chunksize, **kwargs)

